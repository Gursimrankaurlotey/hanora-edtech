console.log("email.js loaded");

emailjs.init("7IkDYH_-MbgnLD3kG");

/* ==========================================================
   STATUS MODAL
========================================================== */

const statusModal = document.getElementById("formStatusModal");
const statusTitle = document.getElementById("statusTitle");
const statusMessage = document.getElementById("statusMessage");
const statusCloseBtn = document.getElementById("statusCloseBtn");
const continueBtn = document.getElementById("continueBtn");

function openStatusModal(title, message) {

    if (!statusModal) {
        console.error("formStatusModal not found.");
        return;
    }

    statusTitle.innerHTML = title;
    statusMessage.innerHTML = message;

    statusModal.classList.add("active");

}

function closeStatusModal() {

    if (!statusModal) return;

    statusModal.classList.remove("active");

}

if (statusCloseBtn) {

    statusCloseBtn.addEventListener("click", closeStatusModal);

}

if (continueBtn) {

    continueBtn.addEventListener("click", closeStatusModal);

}

if (statusModal) {

    statusModal.addEventListener("click", function (e) {

        if (e.target === statusModal) {

            closeStatusModal();

        }

    });

}

document.addEventListener("keydown", function (e) {

    if (e.key === "Escape") {

        closeStatusModal();

    }

});

/* ==========================================================
   SEND EMAIL
========================================================== */

function sendEnquiry(form, templateParams, popupOverlay = null) {

    emailjs.send(

        "service_nxpwhh9",
        "template_sawhvi8",
        templateParams

    )

    .then(function (response) {

        console.log("SUCCESS:", response);

        form.reset();

        if (popupOverlay) {

            popupOverlay.classList.remove("active");

        }

        setTimeout(function () {

            openStatusModal(

                "Thank You!",

                `
                Thank you for contacting <strong>Hanora EdTech</strong>.<br><br>

                We have successfully received your enquiry.

                Our admission counsellors will connect with you shortly to provide personalized guidance regarding programme selection, eligibility, admissions, and the enrolment process.

                <br><br>

                We look forward to supporting you in achieving your academic and professional goals.
                `

            );

        }, 300);

    })

    .catch(function (error) {

        console.error(error);

        openStatusModal(

            "Submission Failed",

            `
            We couldn't submit your enquiry at the moment.

            <br><br>

            Please try again after a few minutes or contact our admission team directly.
            `

        );

    });

}

/* ==========================================================
   FORM SUBMISSION
========================================================== */

document.addEventListener("submit", function (e) {

    const form = e.target;
        /* =====================================
       POPUP FORM
    ===================================== */

    if (form.closest(".popup-right")) {

        e.preventDefault();

        const inputs = form.querySelectorAll("input");
        const select = form.querySelector("select");

        const templateParams = {

            name: inputs[0]?.value.trim() || "",

            email: inputs[1]?.value.trim() || "",

            phone: inputs[2]?.value.trim() || "",

            experience: inputs[3]?.value.trim() || "",

            course: select?.value || "",

            source: "Popup Form",

            message: "New admission enquiry received."

        };

        sendEnquiry(
            form,
            templateParams,
            document.getElementById("popupOverlay")
        );

        return;

    }

    /* =====================================
       CONTACT FORM
    ===================================== */

    if (form.id === "contactForm") {

        e.preventDefault();

        const templateParams = {

            name:
                document.getElementById("contactName")?.value.trim() || "",

            email:
                document.getElementById("contactEmail")?.value.trim() || "",

            phone:
                document.getElementById("contactPhone")?.value.trim() || "",

            course:
                document.getElementById("contactCourse")?.value || "",

            experience:
                "N/A",

            source:
                "Contact Page",

            message:
                document.getElementById("contactMessage")?.value.trim() || ""

        };

        sendEnquiry(form, templateParams);

        return;

    }

});